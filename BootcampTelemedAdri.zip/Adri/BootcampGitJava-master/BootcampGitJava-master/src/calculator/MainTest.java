package calculator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class MainTest {

    public static void main(String[] args)  {


        System.out.printf("Kraj aplikacije");
    }

}
