package com.bootcamp.telemedapp;

public class DoctorPatientInfo {

}
