package com.bootcamp.telemedapp;

import org.springframework.stereotype.Controller;

@Controller
public class HomePatient {

}
