package com.bootcamp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootcampTelemedApplicationTests {

	@Test
	void contextLoads() {
	}

}
